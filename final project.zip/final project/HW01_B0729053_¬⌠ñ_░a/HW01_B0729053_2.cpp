#include<iostream>
#include <algorithm>
#include <string.h>

using namespace std;

int main(){
	char ch;
	int x,i,n,j,space=0,length=1,gap;
	cin>>x;
	cin.get(ch);
	char **NameArray,getName[x][100];
	NameArray=new char*[x];
	for(i=0;i<x;i++){
		cin.getline(getName[i],100);
		size_t n=strlen(getName[i]);
		for(j=0;j<n;j++){
			if(getName[i][j]==' '){
				if(space<j)
				space=j;
				break;
			}
		}
		if(length<(n+1))
		length=n+1;
	}
	for(i=0;i<x;i++){
		NameArray[i]=new char[length];
		for(j=0;j<length;j++){
			NameArray[i][j]=NULL;
		}
	}
	for(i=0;i<x;i++){
		size_t n=strlen(getName[i]);
		for(j=0;j<(n+1);j++)
		NameArray[i][j]=getName[i][j];
	}
	for(i=0;i<x;i++){
		gap=0;
		for(j=0;j<length;j++){
			if(NameArray[i][j]==' '){
				if(j<space)
				gap=space-j;
				break;
			}
		}
		for(j=0;j<gap;j++)
		cout<<" ";
		for(j=0;j<length;j++)
		cout<<NameArray[i][j];
		cout<<"\n";
		delete[] NameArray[i];
	}
	for(i=0;i<x;i++)
	delete[] getName[i];
	delete[] getName;
	for(i=0;i<x;i++)
	delete[] NameArray[i];
	delete[] NameArray;
}
