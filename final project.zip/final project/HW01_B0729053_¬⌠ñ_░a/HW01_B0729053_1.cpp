#include<iostream>
#include <algorithm>
#include <string.h>
using namespace std;

void Bubblesort(char a[],int x)
{ 
	int i,j;
	for(i=x-1;i>0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(a[j]>a[j+1])
			swap(a[j],a[j+1]);
		}
	}
}

int main()
{
	char **Array,**Array1,getArray[256],ch,*sortArray;
	int x,i,n,j,k;
	cin>>x;
	cin.get(ch);
	Array=new char*[x];
	Array1=(char**)malloc(x*sizeof(char*));
	sortArray=new char[x];
	for(i=0;i<x;i++)
	{	
		cin.getline(getArray,256);
		size_t n=strlen(getArray);
		Array[i]=new char[n+1];
		Array1[i]=(char*)malloc((n+1)*sizeof(char));
		for(j=0;j<=n;j++)
		{
			Array[i][j]=getArray[j];
			if(j==0)
			sortArray[i]=getArray[j];
		} 
	}
	n=strlen(sortArray);
	Bubblesort(sortArray,n);
	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++)
		{
			if(Array[j][0]==sortArray[i])
			{
				n=strlen(Array[j]);
				for(k=0;k<n;k++)
				cout<<Array[j][k];
				break;
			}
		}
		cout<<endl;
	}
	delete[] getArray;
	delete[] sortArray;
	for(i=0;i<x;i++)
	delete[] Array[i];
	delete[] Array;
	return 0;
}
