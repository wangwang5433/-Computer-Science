#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	char Iname[80];
	char Oname[80];
	char ch;
	ifstream ifs;
	ofstream ofs;
	
	cout << "Please enter Input file." << endl;
	cin >> Iname;
	ifs.open(Iname);
	
	cout << "Please enter Output file." << endl;
	cin >> Oname;
	ofs.open(Oname);
	
	while(ifs.get(ch))
	{
		
		ch=ch^'z';
		ofs << ch;
		if(ifs.eof())
			break;
	}
	
	ifs.close();
	ofs.close();
}
