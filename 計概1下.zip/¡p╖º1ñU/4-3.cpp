#include <iostream>

using namespace std;

void swapRValue(int &a,int &b);
void swapRValue(int *a,int *b);

int main()
{
	int a,b;
	cout << "�п�J��ӼƦr:";
	cin >> a;
	cin >> b;
	
	swapRValue(a,b);
	cout << a << " " << b << endl;
	swapRValue(&a,&b);
	cout << a << " " << b << endl;
}

void swapRValue(int &a,int &b)
{
	cout << "call by reference." <<endl;
	int next;
	next = a;
	a = b;
	b = next;
}

void swapRValue(int *a,int *b)
{
	cout << " pointer." <<endl;
	int next;
	next = *a;
	*a = *b;
	*b = next;
}
