#include <iostream>
#include <fstream>
using namespace std;
using std::ifstream;
using std::ofstream;

int main()
{
	cout <<"�п�J����ɦW :";
	char name[80];
	char name2[80];	
	cin >> name;
	cin >> name2;

	ifstream myfile;
	ofstream output;
	myfile.open(name);
	output.open(name2);


char ch;
while( true )
{
	myfile.get(ch);
	if( myfile.eof() )
	break;
	ch=ch^'!';
	output<<ch; 
}
	myfile.close();
	output.close();			
	return 0;
}
