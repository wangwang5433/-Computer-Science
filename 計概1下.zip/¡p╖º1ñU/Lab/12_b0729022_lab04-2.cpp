#include<iostream>
#include<cstdlib>
#include<ctime>
#include<cmath>
using namespace std;

int main()
{
	int x,num=0,a=0;
	int *ptr[1024];
	cout<<"�п�J�@��� x (x<=1024):"<<endl;
	cin>>x;
	srand (time(0));
	
	for (int i=0;i<x;i++)
	{
		ptr[i]=new int;
		*(ptr[i])=rand()%201-100;
		
	}
	for(int i=0;i<x;i++)
	{
		num=num+*ptr[i];
		a=a+(*ptr[i]^2);
	}
	
	
	cout<<"������: "<<num/x<<endl;
	cout<<"�зǮt:"<<sqrt(a/x-(num/x)^2)<<endl;

}
