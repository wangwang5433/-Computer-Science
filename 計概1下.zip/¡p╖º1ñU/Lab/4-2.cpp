#include <iostream>
#include <ctime>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() 
{
	int inte=0,*ptr[1024];
	float sum=0,avg=0,se=0,std;
	srand(time(0));
	cout << "Please input a value x (x<= 1024):";
	cin >>inte;	
	
	for(int i=0;i<inte;i++)
	{
		ptr[i]=new int;
		*ptr[i]=(rand()%100+100-1)-100;
		cout <<*ptr[i]<<endl;
		sum+=*ptr[i];
	}	
	avg=sum/inte;
	
	for(int i=0;i<inte;i++)
	{
		se+=pow((*ptr[i]-avg),2);
	}
	std=pow((se/inte),0.5);
	
	cout <<"The averenge is : "<< avg <<endl;
	cout <<"The sd is :"<< std <<endl;	 
}
