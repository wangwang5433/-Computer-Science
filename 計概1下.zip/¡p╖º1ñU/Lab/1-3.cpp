#include <iostream>

using namespace std;

bool isPrime(int num) 

	{
		
		int i;
		for(i=2;i<num;i++)
			{
				if(num%i == 0)
				break;	
			}
		if(i == num)
			return true;
		else
			return false;
	}	

	int main()
	{
		int n,x;
	
		cout << "Please enter a number.";
		cin >> n;
	
		for(x=n;;x++)
	{
			if(isPrime(x) == true)
			{
				cout << x;
				break;
			}
	}
	}
 
