#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<time.h>

using namespace std;

int main()
{
 ifstream inf;
  inf.open("I2.txt");
  
  ofstream outf;
  outf.open("O2.txt");
  
  int num;
  int i=0;
  int arr[3];
  int time=0;
  while(inf>>num)
  {
   arr[i]=num;
   i++;
  }
 outf<<"v1="<<arr[0]<<endl;
 outf<<"v2="<<arr[1]<<endl;
 outf<<"v3="<<arr[2]<<endl;
 
 while(time!=arr[2])
 {
  int a=rand();
  if(a>arr[0] && a<arr[1])
  {
   outf<<a<<endl;
   time++;
  }
 }
 
}
