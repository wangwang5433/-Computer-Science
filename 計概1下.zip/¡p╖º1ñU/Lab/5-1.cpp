#include <iostream>

using namespace std;

void swapRValue(int &a, int &b);
void swapPValue(int *a, int *b);

int main() 
{
	int a,b;
	
	cout <<"�п�J��ӼƦr :"<<endl;
	cin >>a;
	cin >>b;
	
	swapRValue(a,b);
	cout << a << " " << b << endl;
	
	swapRValue(&a,&b);
	cout << a << " " << b << endl;
}


void swapRValue(int &a, int &b)
{
	cout << "Using call by reference." <<endl;
	int next;
	next=a;
	a=b;
	b=next;
}

void swapPValue(int *a, int *b)
{	
	cout << "Using pointer." <<endl;
	int next;
	next=*a;
	*a=*b;
	*b=next;
}
