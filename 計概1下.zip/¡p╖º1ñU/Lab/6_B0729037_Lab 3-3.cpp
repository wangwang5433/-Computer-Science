#include<iostream>
#include<fstream>
using namespace std;

int main()
{
 ifstream inf;
  inf.open("I3.txt");
  
  ofstream outf;
  outf.open("O3.txt");
  
  char ch;
  while(inf.get(ch))
  {
   if(ch<='z' && ch>='a')
   {
    ch=ch-'a'+'A';
   }
   
   outf<<ch;
   if(ch=='\n')
   {
    break;
   }
  }
}
