#include<iostream>
using namespace std;
int main()

int cbfSort(int&v1,int&v2,int&v3,);

{
	int v1,v2,v3;
	
	
}
