#include<iostream>
using namespace std;
int main()
{
	int x,y,n;
	
	cout<<"please input number:"
	cin>>n;	
	
}
