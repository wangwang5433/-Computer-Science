#include<iostream>
#include<fstream>
using namespace std;
 
 int main()
 {
 	ifstream inf;
 	inf.open("I1.txt");
 	
 	ofstream outf;
 	outf.open("O1.txt");
 	
 	int next;
 	while(inf>>next)
 	{
 		next=next+1;
 		bool off=true;
 		while(off)
 		{
 			int i=2;
 			while(next%i!=0)
 			{
 				i++;
			}
			if(i==next)
			{
				outf<<i<<endl;
				off=false;
			}
			next++;
		}
	}	
 }
