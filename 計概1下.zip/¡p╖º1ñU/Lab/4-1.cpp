#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char* argv) 
{
	int *x; 
	char *y;
	int a,b,c;
	
	for(a=0;a<20;a++)
	{
		x=new int; 
		cout << x <<endl;
	}
	for(b=0;b<20;b++)
	{
		y=new char; 
		cout << y <<endl;
	}
	for(c=0;c<20;c++)
	{
		x=new int;
		cout << x <<endl;
		delete x;
	}
		
	return 0;
}
