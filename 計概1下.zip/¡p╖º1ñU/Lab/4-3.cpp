#include <iostream>

using namespace std;

void swapRValue(int &a, int &b);
void swapPValue(int *a, int *b);


void swapRValue(int &a, int &b)
{
	int next;
	next=a;
	a=b;
	b=next;
}

void swapPValue(int *a, int *b)
{
	int next;
	next=*a;
	*a=*b;
	*b=next;
}

int main(int argc, char* argv) 
{
	int a,b;
	
	cout <<"�п�J��ӼƦr :"<<endl;
	cin >>a;
	cin >>b;
	
	swapRValue(a,b);
	cout << "a :" << a <<endl;
	cout << "b :" << b <<endl;
	
	swapPValue(&a,&b);
	cout << "Using call by refrence:" << *&a <<endl;
	cout << "Using call by pointer:" << *&b;
}

