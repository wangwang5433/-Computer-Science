#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

int main()
{
	ifstream fin;
	int t=0;   //t=��� 
	
	fin.open("abc.txt");
	char array[100];
	char strl[100][100];
	
	while(fin.getline(array,100))
	{
		t++;
	}
	cout<<"�`�@��"<<t<<"��";
}
