#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
	srand(time(0));
	
	ifstream ifs;
	ofstream ofs;
	
	int v1,v2,v3,i;
	
	ifs.open("I2.txt");
	if(ifs.fail())
	{
		cout<<"fail.";
		exit(0);
	}
	
	ofs.open("O2.txt");
	if(ofs.fail())
	{
		cout<<"fail.";
		exit(0);
	}
	
	
	ifs >> v1;
	ifs >> v2;
	ifs >> v3;
	
	for(i=0;i<v3;i++)
	{
		ofs<< rand()%(v2-v1+1)+v1 <<",";
	}
}
	
	
	
