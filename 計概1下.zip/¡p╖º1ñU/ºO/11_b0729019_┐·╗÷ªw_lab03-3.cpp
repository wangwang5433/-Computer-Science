#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream inStream;
	ofstream outStream;
	inStream.open("I3.txt");
	outStream.open("O3.txt");
	char ch;
	while(inStream.get(ch))
	{
		if(ch<='z'&&ch>='a')
		{
			ch=ch-'a'+'A';
			outStream<<ch;
		}
		else 
			outStream<<ch; 
		if(ch=='\n')
		{
			break;
		}
	}



	inStream.close();
	outStream.close();
	return 0;	
	
}
