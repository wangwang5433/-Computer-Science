#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream inStream;
	ofstream outStream;
	inStream.open("I1.txt");
	outStream.open("O1.txt");
	int I,i,j,k;
	for(i=0;i<20;i++)
		{
			inStream>>I;
			for(j=I+1;j>I;j++)
			{
				for(k=2;k<j;k++)
					{
						if(j%k==0)
						break;
					}
				
			if(k==j)
			{
				cout<<k<<endl;
				outStream<<k<<endl;
				break;
			}
			}
			
		}
		
	
	inStream.close();
	outStream.close();
	return 0;	
	
}
