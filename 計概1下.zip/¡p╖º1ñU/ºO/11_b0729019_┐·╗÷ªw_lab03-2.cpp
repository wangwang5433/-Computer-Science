#include<iostream>
#include<fstream>
#include<ctime>
#include<cstdlib>

using namespace std;

int main()
{

	ifstream inStream;
	ofstream outStream;
	inStream.open("I2.txt");
	outStream.open("O2.txt");
	int v1,v2,v3,i;
	inStream>>v1>>v2>>v3;
	srand(time(0));
	for(i=0;i<v3;i++)
	{
		outStream <<rand()%(v2-v1+1)+v1<<endl;
	}
	




	inStream.close();
	outStream.close();
	return 0;
	
}
