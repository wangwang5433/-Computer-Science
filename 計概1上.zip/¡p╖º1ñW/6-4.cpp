#include <iostream>
using namespace std;



void outline(int level,int max)
{
	for(int i=0;max-level>i;i++)
		cout<<" ";
	for(int j=0;2*level+1>j;j++)
		cout<<"*";
	cout<<endl;
	
}

int main()
{
	int x[5],sum=0;
	for(int j=0;j<5;sum+=x[j++])
	{
	cin>>x[j];
}cout<<sum;
	
	for(int i=0;i<5;i++)
		outline(i,5);
	
	
	return 0;
}
