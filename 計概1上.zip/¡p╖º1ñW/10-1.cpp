#include <iostream>
#include<ctime>

using namespace std;


bool checkNumber(int x);
{
	


	
	
	
}


int generateNumber(int num);
{
	srand(time(0));
	num=rand()%9876+0123;
	num=checkNumber();
	cout<<num;
	
	
}


int cmpNumber(intx,inty);
{
	int d1,d2,d3,d4;
	int g1,g2,g3,g4;
	
	d1=x/1000;
	d2=(x/100)%10;
	d3=(x/10)%10;
	d4=x%10
	
	g1=y/1000;
	g2=(y/100)%10
	g3=(y/10)%10
	g4=y%10
		
	
	
	
	
}
