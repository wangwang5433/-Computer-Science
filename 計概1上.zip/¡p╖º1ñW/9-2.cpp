#include <iostream>
#include <ctime>
#include<cstdlib>

using namespace std;

int main()
{
	int x,i;
	int randValue;
	int image;
	
	cin>>x;
	
	srand(time(0));
	
	for(i=0;i<x;i++)
	{
		image=rand()%4+1;
		
		switch(image)
		{
			case 1:
			cout<<"S";
			break;
			
			case 2:
			cout<<"H";
			break;
			
			case 3:
			cout<<"D";
			break;
			
			case 4:
			cout<<"C";
			break;
		}
		
		
		randValue=rand()%13+1;
		
		if(randValue<=10&&randValue>1)
			cout<<randValue;
			
		switch(randValue)
		{
			case 11:
	 		cout<<"J";
	 		break;
	 	
			case 12:
	 		cout<<"Q";
		 	break;
	
			case 13:
			cout<<"K";
			break;
			
			case 1:
			cout<<"A";
			break;	
		}
		cout<<",";
	}
	
	return 0;
}

