#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

bool checkNumber(int x) ;
int generateNumber();
int cmpNumber(int x,int y);

int main()
{
	int X, G;
	srand (time(0));
	
	for(;;)
	{
		X = generateNumber();
		if(checkNumber(X) == true)
			break;
	}
	cout << X << endl;
	for(;;)
	{
		cout << "Please enter a number.";
		cin >> G;
		
		cout << (cmpNumber(X,G)/10%10) << "A";
		cout << (cmpNumber(X,G)%10) << "B" << endl;
		
		if(cmpNumber(X,G) == 40)
		{
			cout << "Congratulations! You Win!";
			return 0;
		}
	}
}

int generateNumber()
{
	return rand()%10000;
}

bool checkNumber(int x)
{
	int d1,d2,d3,d4;
	
	d1 = x/1000;
	d2 = (x/100)%10;
	d3 = (x/10)%10;
	d4 = x%10;
	
	if ((d1 == d2)||(d1 == d3)||(d1 == d4)||(d2 == d3)||(d2 == d4)||(d3 == d4))
		return false;
	else 
		return true;
		
}

int cmpNumber(int x,int y)
{
	int d1,d2,d3,d4;
	int g1,g2,g3,g4;
	int i,j;
	i=0;
	j=0;
	
	d1 = x/1000;
	d2 = (x/100)%10;
	d3 = (x/10)%10;
	d4 = x%10;
	
	g1 = y/1000;
	g2 = (y/100)%10;
	g3 = (y/10)%10;
	g4 = y%10;
	
	if((g1 == d2)||(g1 == d3)||(g1 == d4))
		j++;
	else if(g1 == d1)
		i++;

	if((g2 == d1)||(g2 == d3)||(g2 == d4))
		j++;
	else if(g2 == d2)
		i++;

	if((g3 == d1)||(g3 == d1)||(g3 == d4))
		j++;
	else if(g3 == d3)
		i++;

	if((g4 == d1)||(g4 == d3)||(g4 == d1))
		j++;
	else if(g4 == d4)
		i++;

	return i*10+j;
}

