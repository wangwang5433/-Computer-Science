#include <iostream>

using namespace std;

int main()
{
	int x[5];
	float sum=0;
	
	
	for(int i=0;i<5;i++)
	{
		cin>>x[i];
	}
	
	
	for(int j=0;j<5;j++)
	{
	sum=sum+x[j];
	}
	cout<<sum<<endl;
	
	
	float ave=sum/5;
	cout<<ave;
	
	return 0;
	
}
