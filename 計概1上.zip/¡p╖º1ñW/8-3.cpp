#include<iostream>

using namespace std;

int main()
{
	int i=2,j;
	
	while(i<=9)
	{
		j=1;
			while(j<=9)
			{
				cout <<i<<"*"<<j<<"="<<i*j<<endl;
				j++;
			}
	i++;
	}
	return 0;
} 
