#include <iostream>

int main()
{
	
	int x;
	std::cin>>x;
	std::cout << (x*1.732*x/4) << std::endl;
	std::cout << (x*x) << std::endl;
	std::cout << (x*x*3.14) << std::endl;
	std::cout << (x*x*x) << std::endl;
	std::cout << (x*x*x*3.14) << std::endl;
	
	return 0;
}
