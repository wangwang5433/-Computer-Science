#include <iostream>

using namespace std;

int main() 
{
int w,c,y,m,d,year;

	cout<<"please enter year." ;
	cin>>year;
	c=year/100;
	y=year%100;
	
	cout<<"please enter month.";
	cin>> m;
	if(m<=2) 
	{
		m+=12;
		y-=1;
	}
	
	cout<<"please enter day";
	cin>> d;
	
	w=y+y/4+c/4-2*c+26*(m+1)/10+d-1;
	w=(w%7+7)%7;
	

switch(w)
{
	case 1:
		cout<<"Monday"<<endl;
		break;
	case 2:	
		cout<<"Tuesday"<<endl;
		break;
	case 3:
		cout<<"Wednesday"<<endl;
		break;
	case 4:
		cout<<"Thursday"<<endl;
		break;
	case 5:
		cout<<"Friday"<<endl;
		break;
	case 6:
		cout<<"Saturday"<<endl;
		break;
	case 7:
		cout<<"Sunday"<<endl;
		break;
			
}
}
	
	
	
	
	
	
	
	
	










 


