#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>

using namespace std;

int main()
{
	int i,j,k,sum,num[100];
	int Max=99;
	int Min=1001;
	double ave,total,SD;
	
	srand(time(0));
	
	for(i=0;i<100;i++)
	{
		num[i] =rand()%901+100;
	}
	
	for(j=0;j<100;j++)
	{
		if(num[j]>Max)
			Max = num[j];
		if(num[j]<Min)
			Min = num[j];
		sum=sum+num[j];
	}
	ave = sum/100.0;
	
	for(k=0;k<100;k++)
	{
		total=total+(num[k]-ave)*(num[k]-ave);
	}
	SD = sqrt(total/100.0);
	
	cout << "Max is " << Max << endl;
	cout << "Min is " << Min << endl;
	cout << "Ave is " << ave << endl;
	cout << "SD is " << SD;
	
}
