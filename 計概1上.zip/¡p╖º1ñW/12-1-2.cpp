#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

void createCards(int card[],int numberOfCards);
void shuffleCards(int card[],int numberOfCards);
int dealCard(int card[],int remainCards);
void printCard(int x);
const int NUMBER_OF_CARDS=52;

int main()
{
	int card[NUMBER_OF_CARDS];
	int totalCards=NUMBER_OF_CARDS;
	int x;
	srand(time(0));
	
	createCards(card,totalCards);
	shuffleCards(card,totalCards);
	
	cout << "First person get:" << endl;
	for(int i=0;i<13;i++)
	{
		x=dealCard(card,totalCards);
		printCard(x);
		totalCards--;
	}
	cout << endl;
	
	cout << "Second person get:" << endl;
	for(int i=0;i<13;i++)
	{
		x=dealCard(card,totalCards);
		printCard(x);
		totalCards--;
	}
	cout << endl;
	
	cout << "Third person get:" << endl;
	for(int i=0;i<13;i++)
	{
		x=dealCard(card,totalCards);
		printCard(x);
		totalCards--;
	}
	cout << endl;
	
	cout << "Fourth person get:" << endl;
	for(int i=0;i<13;i++)
	{
		x=dealCard(card,totalCards);
		printCard(x);
		totalCards--;
	}
} 

void createCards(int card[],int numberOfCards){
	for(int i=0;i<52;i++)
	{
		card[numberOfCards-1]=51-i;
		numberOfCards--;
	}
	
}

void shuffleCards(int card[],int numberOfCards){
	int a,b,c;
	for(int i=0;i<100;i++)
	{
		a=rand()%numberOfCards;
		b=rand()%numberOfCards;
		c=card[a];
		card[a]=card[b];
		card[b]=c;
	}	
}

int dealCard(int card[],int remainCards){
	return card[remainCards-1];
}

void printCard(int cards){
	int cardnumber,cardface;
	cardface=cards/13+1;
	cardnumber=cards%13+1;
	switch(cardface)
	{
		case 1:
			cout << "S";
			break;
		case 2:
			cout << "H";
			break;
		case 3:
			cout << "D";
			break;
		case 4:
			cout << "C";
			break;
	}
			
		if(cardnumber<=10&&cardnumber>1)
			cout<<cardnumber;
			
		switch(cardnumber)
		{
			case 11:
	 		cout<<"J";
	 		break;
	 	
			case 12:
	 		cout<<"Q";
		 	break;
	
			case 13:
			cout<<"K";
			break;
			
			case 1:
			cout<<"A";
			break;	
		}
		cout<<",";
}
