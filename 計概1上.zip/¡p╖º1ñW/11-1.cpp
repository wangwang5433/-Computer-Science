#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int issueCard();
int cmpCard(int card1, int card2);

int main()
{
	int i,j,k,x;
	int Max=53;
	int Min=13;
	
	srand(time(0));
	
	cout << "Please enter a number.";
	cin >> x;
	int card[x];
	
	for(i=0;i<x;i++)
	{
		card[i] = issueCard();
		switch((card[i]-1)/13+1)
		{
			case 1:
				cout << "S";
				break;
			case 2:
				cout << "H";
				break;
			case 3:
				cout << "D";
				break;
			case 4:
				cout << "C";
				break;
		}
		if((card[i]-1) %13+1 == 1)
			cout << "A\n";
		else if((card[i]-1) %13+1 == 11)
			cout << "J\n";
		else if((card[i]-1) %13+1 == 12)
			cout << "Q\n";
		else if((card[i]-1) %13+1 == 13)
			cout << "K\n";
		else
			cout << (card[i]-1) %13+1 << endl;
	}
	
	for(k=0;k<x;k++)
	{
		
		if(cmpCard(card[k],Min) == -1)
		{
			Min = card[k];
		}
		if(cmpCard(card[k],Max) == 1)
		{
			Max = card[k];
		}
	}
	
	switch((Max-1)/13+1)
	{
		case 1:
			cout << "Max is " << "S";
			break;
		case 2:
			cout << "Max is " << "H";
			break;
		case 3:
			cout << "Max is " << "D";
			break;
		case 4:
			cout << "Max is " << "C";
			break;
	}
	if((Max-1) %13+1 == 1)
		cout << "A\n";
	else if((Max-1) %13+1 == 11)
		cout << "J\n";
	else if((Max-1) %13+1 == 12)
		cout << "Q\n";
	else if((Max-1) %13+1 == 13)
		cout << "K\n";
	else
		cout << (Max-1) %13+1 << endl;
		
	switch((Min-1)/13+1)
	{
		case 1:
			cout << "Min is " << "S";
			break;
		case 2:
			cout << "Min is " << "H";
			break;
		case 3:
			cout << "Min is " << "D";
			break;
		case 4:
			cout << "Min is " << "C";
			break;
	}
	if((Min-1) %13+1 == 1)
		cout << "A\n";
	else if((Min-1) %13+1 == 11)
		cout << "J\n";
	else if((Min-1) %13+1 == 12)
		cout << "Q\n";
	else if((Min-1) %13+1 == 13)
		cout << "K\n";
	else
		cout << (Min-1) %13+1 << endl;
	
} 

int issueCard()
{
	return rand()%52+1;
}

int cmpCard(int card1, int card2)
{
	int num1,num2,suit1,suit2;
	num1 = (card1-1) %13+1;
	num2 = (card2-1) %13+1;
	suit1 = (card1-1) /13+1;
	suit2 = (card2-1) /13+1;
	
	if(num1 == num2)
	{
		if(suit1 < suit2)
			return 1;
		else if(suit1 > suit2)
			return -1;
		else
			return 0;
	}
	if(num1 > num2)
	{
		return 1;
	}
	if(num1 < num2)
	{
		return -1;
	}
}
