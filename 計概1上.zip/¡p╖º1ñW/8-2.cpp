#include <iostream>

using namespace std;

int main()

{
	int y,n,i;
	
	cin>>y;
	
	for(n=2;n<=y;n++)

	{
		for(i=2;i,n;i++)
	{
		if(n%i==0)
		break;
	}
		if(i==n)
		cout<<n<<",";
	}
	
	return 0 ;
}




