#include <iostream>
#include <ctime>
#include <stdlib.h>
using namespace std;

bool checkNumber(int x)
{
	int d1,d2,d3,d4;
	d1=x/1000;
	d2=(x/100)%10;
	d3=(x/10)%10;
	d4=x%10;
	if(d1==d2)
	return false;
	if(d1==d3)
	return false;
	if(d1==d4)
	return false;
	if(d2==d3)
	return false;
	if(d2==d4)
	return false;
	if(d3==d4)
	return false;
	else
	return true;		
}
int generateNumber()
{
	srand(time(0));
	int a=rand()%1000;
	while(checkNumber(a)==false)
	{
		a=rand()%10000;
	}
	return a;
	
}
int gress(int x,int y)
{
	int d1,d2,d3,d4,g1,g2,g3,g4;
	int i=0,j=0;
	d1=x/1000;
	d2=(x/100)%10;
	d3=(x/10)%10;
	d4=x%10;
	g1=y/1000;
	g2=(y/100)%10;
	g3=(y/10)%10;
	g4=y%10;
	if(g1==d2||g1==d3||g1==d4)
		j++;
	if(g1==d1)
		i++;
	if(g2==d1||g2==d3||g2==d4)
		j++;
	if(g2==d2)
		i++;
	if(g3==d1||g3==d2||g3==d4)
		j++;
	if(g3==d3)
		i++;
	if(g4==d1||g4==d2||g4==d3)
		j++;
	if(g4==d4)
		i++;

	return 10*i+j;
	
}
int main()
{
	int user,ans,k,i,j;
	cin>>user;
	ans=generateNumber();
	
	do
	{
		k=gress(user,ans);
		i=k/10;
		j=k%10;
		cout<<i<<"A"<<j<<"B"<<endl;
		cin>>user;
	
	}while(k!=40);
	cout<<"correct";
}

