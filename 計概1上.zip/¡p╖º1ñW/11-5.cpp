#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int issue Card();
int cmpCard(int card1,int card2);

int main()
{
	int i,x;
	srand(time(0));
	
	cout<<"Please enter a numer";
	cin>>x;
	
	for(i=0;i<x;i++)
	{
		card=issueCard();
		swich((card-1)/(13+1))
		{
			case 1:
			cout<<"S";
			break;
			
			case 2:
			cout<<"H";
			break;
			
			case 3:
			cout<<"D";
			break;
			
			case 4:
			cout<<"C";
			break;
		}
		cout<<(card-1)%13+1<<"\";
	}
}

int issueCard();
{
	return rand()%52+1;	
}

int cmpCard(int card1,int card2);
{
	int i,num1,num2,suit1,suit2);
	num1=(card1-1)%13+1
	num2=(card2-1)%13+1
	suit1=(card1-1)/13+1;
	suit2=(card2-1)/13+1;
	
	if(num1==num2)
	{
		if(suit1 > suit2)	
			return1;
		else if(suit1 < suit)
			return-1;
		else
			return0;
	}	
	
	
	
}
